package Page;

import Base.BasePage;
import io.appium.java_client.AppiumDriver;

public class MainPage extends BasePage{

	public MainPage(AppiumDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

}
